# PyCode
1. ارفع كل الملفات دي على repo جديد في GitHub (branch اسمه main).
2. من تبويب Actions شغّل "Build APK" (أول بناء ممكن ياخد 40-60 دقيقة بسبب OpenCV).
3. نزّل الـ APK من Artifacts وثبّته.

اختصارات الكيبورد: Ctrl+S حفظ، Ctrl+R/F5 تشغيل، Ctrl+N جديد، Ctrl+O فتح، Ctrl+F بحث (old=>new للاستبدال)، Ctrl+/ تعليق، Ctrl+D تكرار سطر، Ctrl+P سنيبتس.
زر "Cfg files" بيفتح pycode.ini و shortcuts.json و snippets.json تعدلهم وتحفظ وتتطبق فوراً.
في الكود: show(img) أو cv2.imshow بيعرضوا الصورة في نافذة.
