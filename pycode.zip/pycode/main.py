import os, sys, json, io, ctypes, threading, traceback
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.resources import resource_find
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.codeinput import CodeInput
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.settings import SettingsWithSidebar
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from pygments.lexers import PythonLexer

PAIRS = {'(': ')', '[': ']', '{': '}', '"': '"', "'": "'"}
STYLES = ['monokai', 'dracula', 'native', 'one-dark', 'nord', 'gruvbox-dark', 'material',
          'zenburn', 'solarized-dark', 'default', 'friendly', 'vim']
# '|' marks where the cursor ends up after insertion
DEF_SHORT = [["Tab", "    "], ["()", "(|)"], ["[]", "[|]"], ["{}", "{|}"], ['""', '"|"'],
             ["''", "'|'"], [":", ":"], ["=", "="], ["#", "#"], ["self.", "self."],
             ["print", "print(|)"], ["def", "def |():\n    "], ["for", "for i in range(|):\n    "],
             ["if", "if |:\n    "], ["import", "import "], ["cv2", "import cv2\nimport numpy as np\n"]]
DEF_SNIP = {
    "main": "if __name__ == '__main__':\n    |",
    "class": "class |:\n    def __init__(self):\n        pass\n",
    "try/except": "try:\n    |\nexcept Exception as e:\n    print(e)\n",
    "with open": "with open('|') as f:\n    data = f.read()\n",
    "cv2 read+show": "import cv2\nimg = cv2.imread('|')\nshow(img)\n",
    "cv2 gray": "gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)\nshow(gray)\n",
    "cv2 canny": "edges = cv2.Canny(gray, 100, 200)\nshow(edges)\n",
    "cv2 blank image": "import numpy as np\nimg = np.zeros((300, 300, 3), np.uint8)\ncv2.circle(img, (150, 150), 80, (0, 255, 0), 3)\nshow(img)\n",
}
WELCOME = "import cv2, numpy as np\nprint('cv2', cv2.__version__)\nimg = np.zeros((200, 400, 3), np.uint8)\ncv2.putText(img, 'Hello', (20, 120), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 255, 0), 4)\nshow(img)\n"


def S(t, title, key, sec, desc='', **kw):
    d = {'type': t, 'title': title, 'desc': desc, 'section': sec, 'key': key}
    d.update(kw)
    return d


PANELS = {
    'Editor': [
        S('numeric', 'Font size', 'font_size', 'editor'),
        S('string', 'Font (path or kivy resource)', 'font_name', 'editor'),
        S('options', 'Theme', 'style', 'editor', options=STYLES),
        S('numeric', 'Tab width', 'tab_width', 'editor'),
        S('bool', 'Auto indent', 'auto_indent', 'editor'),
        S('bool', 'Auto close brackets/quotes', 'auto_pair', 'editor'),
        S('numeric', 'Line spacing', 'line_spacing', 'editor'),
        S('numeric', 'Cursor width', 'cursor_width', 'editor'),
        S('numeric', 'Autosave every N seconds (0=off)', 'autosave', 'editor')],
    'UI': [
        S('numeric', 'Console height (dp)', 'console_height', 'ui'),
        S('numeric', 'Console font size', 'console_font', 'ui'),
        S('numeric', 'Bar height (dp)', 'bar_height', 'ui'),
        S('options', 'Keyboard mode', 'softinput', 'ui', options=['resize', 'below_target', 'pan', ''])],
    'Run & Files': [
        S('bool', 'Clear console on run', 'clear_console', 'run'),
        S('numeric', 'Max console lines', 'max_lines', 'run'),
        S('bool', 'Inject show() & patch cv2.imshow', 'helpers', 'run'),
        S('string', 'Projects folder (empty = default)', 'dir', 'files')],
    'Pip': [
        S('string', 'Index URL (empty = PyPI)', 'index_url', 'pip'),
        S('string', 'Extra pip args', 'extra_args', 'pip')],
}


class Out:
    def __init__(self, fn): self.fn = fn
    def write(self, s): Clock.schedule_once(lambda dt, s=s: self.fn(s))
    def flush(self): pass


class Editor(CodeInput):
    def insert_text(self, sub, from_undo=False):
        a = App.get_running_app()
        if not from_undo and a:
            c = a.config
            try:
                line = self._lines[self.cursor_row]
            except Exception:
                line = ''
            col = self.cursor_col
            nxt = line[col] if col < len(line) else ''
            prev = line[col - 1] if col > 0 else ''
            if sub == '\n' and c.getint('editor', 'auto_indent'):
                ind = line[:len(line) - len(line.lstrip())]
                if line[:col].rstrip().endswith(':'):
                    ind += ' ' * int(c.getfloat('editor', 'tab_width'))
                sub = '\n' + ind
            elif c.getint('editor', 'auto_pair') and len(sub) == 1:
                if sub in PAIRS.values() and nxt == sub:
                    self.do_cursor_movement('cursor_right'); return
                if sub in PAIRS and not (sub in '"\'' and prev.isalnum()):
                    super().insert_text(sub + PAIRS[sub], from_undo)
                    self.do_cursor_movement('cursor_left'); return
        return super().insert_text(sub, from_undo=from_undo)

    def keyboard_on_key_down(self, window, keycode, text, modifiers):
        a = App.get_running_app(); k = keycode[1]
        if k == 'f5': a.run(); return True
        if 'ctrl' in modifiers:
            m = {'s': a.save, 'r': a.run, 'n': a.new, 'o': a.open_dlg, 'f': a.find_dlg,
                 '/': a.comment, 'd': a.dup_line, 'p': a.snip_dlg, 'q': a.stop}
            if k in m: m[k](); return True
        return super().keyboard_on_key_down(window, keycode, text, modifiers)


class IDE(App):
    use_kivy_settings = False
    settings_cls = SettingsWithSidebar

    def build_config(self, c):
        c.setdefaults('editor', {'font_size': 16, 'font_name': 'data/fonts/RobotoMono-Regular.ttf',
                                 'style': 'monokai', 'tab_width': 4, 'auto_indent': 1, 'auto_pair': 1,
                                 'line_spacing': 2, 'cursor_width': 2, 'autosave': 0})
        c.setdefaults('ui', {'console_height': 160, 'console_font': 13, 'bar_height': 44, 'softinput': 'resize'})
        c.setdefaults('run', {'clear_console': 1, 'max_lines': 500, 'helpers': 1})
        c.setdefaults('files', {'dir': ''})
        c.setdefaults('pip', {'index_url': '', 'extra_args': ''})

    def get_application_config(self):
        return os.path.join(self.user_data_dir, 'pycode.ini')

    def build_settings(self, s):
        for name, items in PANELS.items():
            s.add_json_panel(name, self.config, data=json.dumps(items))

    def on_config_change(self, *a): self.apply()

    # ---------- UI ----------
    def strip(self, h):
        sv = ScrollView(size_hint_y=None, height=h, do_scroll_y=False, bar_width=0)
        g = GridLayout(rows=1, size_hint_x=None, spacing=dp(3), padding=dp(2))
        g.bind(minimum_width=g.setter('width')); sv.add_widget(g)
        return sv, g

    def fill(self, g, items):
        g.clear_widgets()
        for lbl, cb in items:
            b = Button(text=lbl, size_hint_x=None, width=max(dp(56), dp(13) * len(lbl) + dp(24)),
                       background_color=(.2, .22, .3, 1))
            b.bind(on_release=lambda *_, cb=cb: cb()); g.add_widget(b)

    def build(self):
        self.title = 'PyCode'
        self.docs, self.cur, self.thread = [], None, None
        self.proj = self.config.get('files', 'dir') or os.path.join(self.user_data_dir, 'projects')
        self.libs = os.path.join(self.user_data_dir, 'libs')
        for d in (self.proj, self.libs): os.makedirs(d, exist_ok=True)
        sys.path.insert(0, self.libs)
        root = BoxLayout(orientation='vertical')
        self.status = Label(size_hint_y=None, height=dp(22), font_size='11sp', text='ready')
        self.topsv, g = self.strip(dp(44))
        self.fill(g, [('New', self.new), ('Open', self.open_dlg), ('Save', self.save), ('Run ▶', self.run),
                      ('Stop', self.stop), ('Close', self.close_tab), ('Find', self.find_dlg),
                      ('Snippets', self.snip_dlg), ('Pip', self.pip_dlg), ('Cfg files', self.cfg_dlg),
                      ('Console', self.toggle_console), ('Settings', self.open_settings),
                      ('Undo', lambda: self.ed.do_undo()), ('Redo', lambda: self.ed.do_redo()),
                      ('Comment', self.comment), ('Dup line', self.dup_line)])
        self.tabs = Spinner(text='-', size_hint_y=None, height=dp(38))
        self.tabs.bind(text=self.pick)
        self.ed = Editor(lexer=PythonLexer(), size_hint_y=1)
        self.shsv, self.shg = self.strip(dp(44))
        self.csv = ScrollView(size_hint_y=None)
        self.con = Label(size_hint_y=None, halign='left', valign='top', markup=False)
        self.con.bind(width=lambda w, v: setattr(w, 'text_size', (v, None)),
                      texture_size=lambda w, v: setattr(w, 'height', v[1]))
        self.csv.add_widget(self.con)
        for w in (self.topsv, self.tabs, self.ed, self.shsv, self.csv, self.status): root.add_widget(w)
        self.reload()
        w = os.path.join(self.proj, 'welcome.py')
        if not os.path.exists(w): open(w, 'w').write(WELCOME)
        self.add_doc(w)
        return root

    def jload(self, name, default):
        p = os.path.join(self.user_data_dir, name)
        if not os.path.exists(p):
            json.dump(default, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        try: return json.load(open(p, encoding='utf-8'))
        except Exception as e:
            self.status.text = 'bad %s: %s' % (name, e); return default

    def reload(self):
        self.snips = self.jload('snippets.json', DEF_SNIP)
        self.fill(self.shg, [(l, lambda t=t: self.put(t)) for l, t in self.jload('shortcuts.json', DEF_SHORT)])
        self.apply()

    def apply(self):
        c, e = self.config, self.ed
        try:
            e.font_size = c.getfloat('editor', 'font_size')
            fn = c.get('editor', 'font_name'); e.font_name = resource_find(fn) or fn
            e.style_name = c.get('editor', 'style')
            e.tab_width = int(c.getfloat('editor', 'tab_width'))
            e.line_spacing = c.getfloat('editor', 'line_spacing')
            e.cursor_width = c.getfloat('editor', 'cursor_width')
            self.con.font_size = c.getfloat('ui', 'console_font')
            self.con.font_name = e.font_name
            self.chh = dp(c.getfloat('ui', 'console_height')); self.csv.height = self.chh
            bh = dp(c.getfloat('ui', 'bar_height')); self.topsv.height = self.shsv.height = bh
            Window.softinput_mode = c.get('ui', 'softinput')
            Clock.unschedule(self.tick)
            n = c.getfloat('editor', 'autosave')
            if n > 0: Clock.schedule_interval(self.tick, n)
        except Exception as ex:
            self.status.text = 'settings error: %s' % ex

    def tick(self, dt): self.save(quiet=True)

    def toggle_console(self): self.csv.height = 0 if self.csv.height else self.chh

    # ---------- dialogs ----------
    def ask(self, title, default, cb):
        ti = TextInput(text=default, multiline=False, size_hint_y=None, height=dp(44))
        ok = Button(text='OK', size_hint_y=None, height=dp(44))
        box = BoxLayout(orientation='vertical', spacing=dp(6), padding=dp(6))
        box.add_widget(ti); box.add_widget(ok)
        p = Popup(title=title, content=box, size_hint=(.92, None), height=dp(190))
        def go(*_): p.dismiss(); cb(ti.text)
        ok.bind(on_release=go); ti.bind(on_text_validate=go); p.open()
        Clock.schedule_once(lambda dt: setattr(ti, 'focus', True), .2)

    def listpop(self, title, items, cb):
        g = GridLayout(cols=1, size_hint_y=None, spacing=dp(4)); g.bind(minimum_height=g.setter('height'))
        p = Popup(title=title, size_hint=(.92, .8))
        for it in items:
            b = Button(text=it, size_hint_y=None, height=dp(46))
            b.bind(on_release=lambda *_, it=it: (p.dismiss(), cb(it))); g.add_widget(b)
        sv = ScrollView(); sv.add_widget(g); p.content = sv; p.open()

    def open_dlg(self):
        fc = FileChooserListView(path=self.proj)
        p = Popup(title='Open', content=fc, size_hint=(.95, .9))
        fc.bind(on_submit=lambda w, sel, t: (p.dismiss(), sel and self.add_doc(sel[0])))
        p.open()

    def cfg_dlg(self):
        self.listpop('Config files (edit & save)', ['pycode.ini', 'shortcuts.json', 'snippets.json'],
                     lambda n: self.add_doc(os.path.join(self.user_data_dir, n)))

    def snip_dlg(self): self.listpop('Snippets', list(self.snips), lambda k: self.put(self.snips[k]))

    # ---------- documents ----------
    def add_doc(self, path, text=None):
        self.sync()
        for d in self.docs:
            if d['path'] == path: return self.switch(d)
        if text is None: text = open(path, encoding='utf-8', errors='replace').read()
        d = {'path': path, 'text': text}; self.docs.append(d); self.switch(d)

    def switch(self, d):
        self.cur = d; self.ed.text = d['text']
        self.tabs.values = [os.path.basename(x['path']) for x in self.docs]
        self.tabs.text = os.path.basename(d['path'])

    def sync(self):
        if self.cur: self.cur['text'] = self.ed.text

    def pick(self, sp, t):
        if self.cur and t != os.path.basename(self.cur['path']):
            self.sync()
            for d in self.docs:
                if os.path.basename(d['path']) == t: self.switch(d); break

    def new(self):
        def ok(n):
            n = n if '.' in n else n + '.py'
            self.add_doc(os.path.join(self.proj, n), '')
        self.ask('New file', 'main.py', ok)

    def save(self, quiet=False):
        if not self.cur: return
        self.sync(); p = self.cur['path']
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, 'w', encoding='utf-8').write(self.cur['text'])
        if os.path.basename(p) in ('pycode.ini', 'shortcuts.json', 'snippets.json'):
            self.config.read(self.get_application_config()); self.reload()
        if not quiet: self.status.text = 'saved ' + p

    def close_tab(self):
        if not self.cur: return
        self.docs.remove(self.cur)
        if not self.docs: self.docs.append({'path': os.path.join(self.proj, 'untitled.py'), 'text': ''})
        self.cur = None; self.switch(self.docs[-1])

    # ---------- editing helpers ----------
    def put(self, t):
        back = 0
        if '|' in t:
            t, post = t.split('|', 1); back = len(post); t += post
        self.ed.insert_text(t)
        for _ in range(back): self.ed.do_cursor_movement('cursor_left')
        Clock.schedule_once(lambda dt: setattr(self.ed, 'focus', True), .05)

    def _lines_edit(self, fn):
        col, row = self.ed.cursor; ls = self.ed.text.split('\n'); fn(ls, row)
        self.ed.text = '\n'.join(ls); self.ed.cursor = (col, min(row, len(ls) - 1))

    def comment(self):
        def f(ls, r):
            ls[r] = ls[r].replace('# ', '', 1) if ls[r].lstrip().startswith('# ') else \
                (ls[r].replace('#', '', 1) if ls[r].lstrip().startswith('#') else '# ' + ls[r])
        self._lines_edit(f)

    def dup_line(self): self._lines_edit(lambda ls, r: ls.insert(r + 1, ls[r]))

    def find_dlg(self):
        def go(q):
            if '=>' in q:
                a, b = q.split('=>', 1); self.ed.text = self.ed.text.replace(a, b)
                self.status.text = 'replaced all'; return
            t = self.ed.text; i = t.find(q, self.ed.cursor_index() + 1)
            if i < 0: i = t.find(q)
            if i < 0: self.status.text = 'not found'; return
            self.ed.cursor = self.ed.get_cursor_from_index(i)
            self.ed.select_text(i, i + len(q))
        self.ask('Find  (or  old=>new  to replace all)', '', go)

    # ---------- run / pip ----------
    def log(self, s):
        t = (self.con.text + s).split('\n')
        self.con.text = '\n'.join(t[-int(self.config.getfloat('run', 'max_lines')):])
        Clock.schedule_once(lambda dt: setattr(self.csv, 'scroll_y', 0))

    def bg(self, fn):
        def job():
            old = sys.stdout, sys.stderr; sys.stdout = sys.stderr = Out(self.log)
            try: fn()
            except SystemExit: pass
            except BaseException: traceback.print_exc()
            finally:
                sys.stdout, sys.stderr = old; Clock.schedule_once(lambda dt: self.log('\n■ done\n'))
        self.thread = threading.Thread(target=job, daemon=True); self.thread.start()

    def show(self, img, title='image'):
        import cv2
        ok, buf = cv2.imencode('.png', img); data = buf.tobytes()
        def ui(dt):
            from kivy.core.image import Image as CI
            from kivy.uix.image import Image
            Popup(title=str(title), content=Image(texture=CI(io.BytesIO(data), ext='png').texture),
                  size_hint=(.95, .8)).open()
        Clock.schedule_once(ui)

    def run(self):
        if self.thread and self.thread.is_alive(): self.status.text = 'already running'; return
        self.sync(); self.save(quiet=True)
        code, path = self.ed.text, self.cur['path']
        if self.config.getint('run', 'clear_console'): self.con.text = ''
        os.chdir(os.path.dirname(path))
        def go():
            g = {'__name__': '__main__', '__file__': path}
            if self.config.getint('run', 'helpers'):
                g['show'] = self.show
                if 'cv2' in code:
                    import cv2
                    cv2.imshow = lambda t, i: self.show(i, t)
                    cv2.waitKey = lambda *a: 0; cv2.destroyAllWindows = lambda *a: None
            exec(compile(code, path, 'exec'), g)
        self.bg(go)

    def stop(self):
        if self.thread and self.thread.is_alive():
            ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(self.thread.ident),
                                                       ctypes.py_object(KeyboardInterrupt))

    def pip_dlg(self):
        def ok(spec):
            def go():
                from pip._internal.cli.main import main
                c = self.config; a = ['install', '--target', self.libs, '--upgrade', '--no-warn-script-location']
                if c.get('pip', 'index_url'): a += ['--index-url', c.get('pip', 'index_url')]
                a += c.get('pip', 'extra_args').split() + spec.split()
                print('pip', ' '.join(a)); main(a)
            self.bg(go)
        self.ask('pip install (pure-Python packages)', '', ok)


if __name__ == '__main__':
    IDE().run()
