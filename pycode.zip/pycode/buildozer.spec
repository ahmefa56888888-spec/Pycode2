[app]
title = PyCode
package.name = pycode
package.domain = org.ahmed
source.dir = .
source.include_exts = py,png,jpg,json
version = 1.0
requirements = python3,kivy==2.3.0,pygments,numpy,opencv,pip,setuptools
orientation = all
fullscreen = 0
android.permissions = INTERNET,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE
android.api = 33
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
